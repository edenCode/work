#include <iostream>
#include <string>

using namespace std;
#define URL "rtmp://192.168.100.1:665/h264"
int main()
{
	string str(URL);
	size_t  pos = 0;
	string s;
	if( (pos = str.find("://")) != string::npos)
	{
		string  st = str.substr(pos);
		string 	st1= str.substr(0,pos);
		cout <<" " << st << endl;
		cout <<" " << st1 << endl;
		
		pos = str.find("/");
		s = str.substr(0,pos);
		cout <<" " << s << endl;
	}
	
	return 0;
}